$( document ).ready(function() {
    // DOM ready

    // Test data
    /*
     * To test the script you should discomment the function
     * testLocalStorageData and refresh the page. The function
     * will load some test data and the loadProfile
     * will do the changes in the UI
     */
    // testLocalStorageData();
    // Load profile if it exits
    loadProfile();
});

/**
 * Function that gets the data of the profile in case
 * thar it has already saved in localstorage. Only the
 * UI will be update in case that all data is available
 *
 * A not existing key in localstorage return null
 *
 */
function getLocalProfile(callback){
    var profileImgSrc      = localStorage.getItem("PROFILE_IMG_SRC");
    var profileName        = localStorage.getItem("PROFILE_NAME");
    var profileReAuthEmail = localStorage.getItem("PROFILE_REAUTH_EMAIL");

    if(profileName !== null
            && profileReAuthEmail !== null
            && profileImgSrc !== null) {
        callback(profileImgSrc, profileName, profileReAuthEmail);
    }
}

/**
 * Main function that load the profile if exists
 * in localstorage
 */
function loadProfile() {
    if(!supportsHTML5Storage()) { return false; }
    // we have to provide to the callback the basic
    // information to set the profile
    getLocalProfile(function(profileImgSrc, profileName, profileReAuthEmail) {
        //changes in the UI
        $("#profile-img").attr("src",profileImgSrc);
        $("#profile-name").html(profileName);
        $("#reauth-email").html(profileReAuthEmail);
        $("#inputEmail").hide();
        $("#remember").hide();
    });
}

/**
 * function that checks if the browser supports HTML5
 * local storage
 *
 * @returns {boolean}
 */
function supportsHTML5Storage() {
    try {
        return 'localStorage' in window && window['localStorage'] !== null;
    } catch (e) {
        return false;
    }
}

/**
 * Test data. This data will be safe by the web app
 * in the first successful login of a auth user.
 * To Test the scripts, delete the localstorage data
 * and comment this call.
 *
 * @returns {boolean}
 */
function testLocalStorageData() {
    if(!supportsHTML5Storage()) { return false; }
    localStorage.setItem("PROFILE_IMG_SRC", "//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" );
    localStorage.setItem("PROFILE_NAME", "César Izquierdo Tello");
    localStorage.setItem("PROFILE_REAUTH_EMAIL", "oneaccount@gmail.com");
}

$(document).ready(function() {
    jQuery.validator.addMethod("username", function(value, element) {
        if (/[a-zA-Z0-9._-]$/.test(value)) {
            return true;   // PASS validation when REGEX matches
        } else {
            return false;  // FAIL validation
        };
    }, 'Tài khoản chỉ chấp nhận a->z, A->Z, 0->9 hoặc các ký tự ._-');

    $('#login-form').validate({
        rules: {
            username:{
                minlength: 4,
                maxlength: 16,
                username: true,
            },
            password: {
                minlength: 6
            }
        },
        messages: {
            username: {
                required: "Vui lòng nhập tài khoản.",
                minlength: "Độ dài tối thiểu 4 ký tự.",
                maxlength: "Độ dài tối đa 16 ký tự.",
            },
            password: {
                required: "Vui lòng nhập mật khẩu.",
                minlength: "Độ dài tối thiểu 6 ký tự."
            }
        }
    });

    $('#btn-signin').click(function(event) {
        var validationResult = $('#login-form').valid();
        if(validationResult){
            var url = "/cPanel/signin.php";
            var method = 'POST';
            var username = ($('#username').val() && $('#username').val() !== '') ? $('#username').val() : '';
            var password = ($('#password').val() && $('#password').val() !== '') ? $('#password').val() : '';
            var saveme   =  $('#saveme').is(":checked");
            
            $.ajax({
                url: url,
                type: method,
                data: {
                    username: username,
                    password: password,
                    signal  : 1,
                    saveme  : saveme
                },
                beforeSend: function(){
                    $('#btn-signin').button('loading');
                },
                success: function(result) {
                    $('#btn-signin').button('reset');
                    
                    var data = JSON.parse(result);
                    if(data.status == 1){
                        window.location.href = '/cPanel/index.php';
                    }else{
                        $('#alert-login').html(
                            '<div class="alert alert-danger alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+data.msg+'</div>'
                            );
                    }
                },
                error: function(xhr, textStatus, error) {
                    $('#btn-signin').button('reset');
                    alert('Lỗi rồi');
                }
            });
        }
    });

    $(document).keypress(function(e) {
        if(e.which == 13) {
            var validationResult = $('#login-form').valid();
            if(validationResult){
                var url = "/cPanel/signin.php";
                var method = 'POST';
                var username = ($('#username').val() && $('#username').val() !== '') ? $('#username').val() : '';
                var password = ($('#password').val() && $('#password').val() !== '') ? $('#password').val() : '';
                var saveme   =  $('#saveme').is(":checked");
                
                $.ajax({
                    url: url,
                    type: method,
                    data: {
                        username: username,
                        password: password,
                        signal  : 1,
                        saveme  : saveme
                    },
                    beforeSend: function(){
                        $('#btn-signin').button('loading');
                    },
                    success: function(result) {
                        $('#btn-signin').button('reset');
                        
                        var data = JSON.parse(result);
                        if(data.status == 1){
                            window.location.href = '/cPanel/index.php';
                        }else{
                            $('#alert-login').html(
                                '<div class="alert alert-danger alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+data.msg+'</div>'
                                );
                        }
                    },
                    error: function(xhr, textStatus, error) {
                        $('#btn-signin').button('reset');
                        alert('Lỗi rồi');
                    }
                });
            }
        }
    });
});