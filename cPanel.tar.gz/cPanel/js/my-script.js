$(document).ready(function() {
	$('.custom-alert').fadeIn('400');
	loadMonitor();
	function loadMonitor(){
	    var url = "/cPanel/monitor.php";
        var method = 'POST';
        $('#disk_process').html("0%");
        $('#mem_process').html("0%");
        $('#cpu_process').html("0%");
        
        $('#disk_process').css("width","0%");
        $('#mem_process').css("width","0%");
        $('#cpu_process').css("width","0%");
	    $.ajax({
            url: url,
            type: method,
            data: {
                signal: 1,
            },
            beforeSend: function(){
                $('#refresh_btn').button('loading');
            },
            success: function(result) {
                var data = JSON.parse(result);
                var disk = data[0];
                $('#disk_text').html(disk);
                disk = Math.round(eval(disk)*100);
                var mem = data[1];
                $('#memory_text').html(mem);
                mem = Math.round(eval(mem)*100);
                var cpu = data[2];
                $('#cpu_text').html(cpu);
                
                $('#disk_process').html(disk+"%");
                $('#memory_process').html(mem+"%");
                $('#cpu_process').html(cpu+"%");
                
                $('#disk_process').css("width",disk+"%");
                $('#memory_process').css("width",mem+"%");
                $('#cpu_process').css("width",cpu);
                $('#refresh_btn').button('reset');
            },
            error: function(xhr, textStatus, error) {
            	$('#refresh_btn').button('reset');
            }
        });
	}
	
	$('#refresh_btn').click(function(){
	    loadMonitor();
	});
	
	$('#restart_btn').click(function(){
	    var url = "/cPanel/monitor.php";
        var method = 'POST';
        $('#disk_process').html("0%");
        $('#mem_process').html("0%");
        $('#cpu_process').html("0%");
        
        $('#disk_process').css("width","0%");
        $('#mem_process').css("width","0%");
        $('#cpu_process').css("width","0%");
	    $.ajax({
            url: url,
            type: method,
            data: {
                signal: 2,
            },
            beforeSend: function(){
                $('#restart_btn').button('loading');
            },
            success: function(result) {
                var data = JSON.parse(result);
                var disk = data[0];
                $('#disk_text').html(disk);
                disk = Math.round(eval(disk)*100);
                var mem = data[1];
                $('#memory_text').html(mem);
                mem = Math.round(eval(mem)*100);
                var cpu = data[2];
                $('#cpu_text').html(cpu);
                
                $('#disk_process').html(disk+"%");
                $('#memory_process').html(mem+"%");
                $('#cpu_process').html(cpu+"%");
                
                $('#disk_process').css("width",disk+"%");
                $('#memory_process').css("width",mem+"%");
                $('#cpu_process').css("width",cpu);
                $('#restart_btn').button('reset');
            },
            error: function(xhr, textStatus, error) {
            	$('#restart_btn').button('reset');
            }
        });
	});
});


$(document).ready(function() {
	$('#saveWebsite').click(function(event) {
		jQuery.validator.addMethod("userpassword", function(value, element) {
			if (/[a-zA-Z0-9.!#%+_-]$/.test(value)) {
		        return true;   // PASS validation when REGEX matches
		    } else {
		        return false;  // FAIL validation
		    };
		}, 'Password must be in a->z, A->Z, 0->9 or those .!#%+_-');

		jQuery.validator.addMethod("username", function(value, element) {
			if (/[a-zA-Z0-9.!#%+_-]$/.test(value)) {
		        return true;   // PASS validation when REGEX matches
		    } else {
		        return false;  // FAIL validation
		    };
		}, 'Username must be in a->z, A->Z, 0->9 or those .!#%+_-');

		jQuery.validator.addMethod("dbname", function(value, element) {
			if (/[a-zA-Z0-9._-]$/.test(value)) {
		        return true;   // PASS validation when REGEX matches
		    } else {
		        return false;  // FAIL validation
		    };
		}, 'Database name must be in a->z, A->Z, 0->9 or those ._-');

		jQuery.validator.addMethod("domain", function(value, element) {
			if (/^(?!\-)(?:[a-zA-Z\d\-]{0,62}[a-zA-Z\d]\.){1,126}(?!\d+)[a-zA-Z\d]{1,63}$/.test(value)) {
		        return true;   // PASS validation when REGEX matches
		    } else {
		        return false;  // FAIL validation
		    };
		}, 'Domain is incorrect. Example: mydomain.com');

		$('#saveForm').validate({
			rules: {
	            dbpassword:{
	            	minlength: 8,
	            	userpassword: true,
	            },
	            dbusername:{
	            	minlength: 3,
	            	maxlength: 16,
	            	username: true,
	            },
	            dbname:{
	            	minlength: 3,
	            	maxlength: 64,
	            	dbname: true,
	            },
	            email: {
	            	email: true,
	            },
	            domainname: {
	            	domain:true,
	            }
	        },
	        messages:{
	            domainname:{
	            	required: "This field is required."
	            }, 
	            email:{
	            	required: "This field is required.",
	            	email: "Email is incorrect."
	            },
	            dbname:{
	            	required: "This field is required.",
	            	maxlength: "Maximum length is 64 characters.",
	            	minlength: "Minimum length is 3 characters.",
	            },
	            dbusername:{
	            	required: "This field is required.",
	            	maxlength: "Maximum length is 16 characters.",
	            	minlength: "Minimum length is 3 characters.",
	            },
	            dbpassword:{
	            	required: "This field is required.",
	            	minlength: "Minimum length is 8 characters."
	            }
	        },
		});

		var validationResult = $('#saveForm').valid();
		if(validationResult){
			var url = "/cPanel/process.php";
	        var method = 'POST';
	        var cms = ($('#cms').val() && $('#cms').val() !== '') ? $('#cms').val() : '';
	        var domainname = ($('#domainname').val() && $('#domainname').val() !== '') ? $('#domainname').val() : '';
	        var email = ($('#email').val() && $('#email').val() !== '') ? $('#email').val() : '';
	        var dbname = ($('#dbname').val() && $('#dbname').val() !== '') ? $('#dbname').val() : '';
	        var dbusername = ($('#dbusername').val() && $('#dbusername').val() !== '') ? $('#dbusername').val() : '';
	        var dbpassword = ($('#dbpassword').val() && $('#dbpassword').val() !== '') ? $('#dbpassword').val() : '';
	        
	        $.ajax({
	            url: url,
	            type: method,
	            data: {
	                postType: 1,
	                cms: cms,
	                domainname: domainname,
	                email: email,
	                dbname: dbname,
	                dbusername: dbusername,
	                dbpassword: dbpassword,
	            },
	            beforeSend: function(){
	                $('#saveWebsite').button('loading');
	                $("select, input").attr('disabled','disabled');
	            },
	            success: function(result) {
	            	$('#saveWebsite').button('reset');
	                $('#save_alert').hide().html(' <div class="alert alert-danger alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+result+'</div>').fadeIn('400');
	                $("select, input").removeAttr('disabled');
	            },
	            error: function(xhr, textStatus, error) {
	            	$('#saveWebsite').button('reset');
					$('#save_alert').hide().html(' <div class="alert alert-success alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Your website is created successfully! Click <a target="_blank" href=http://'+domainname+'>HERE</a> to continue installation.</div>').fadeIn('400');
					$("select, input").removeAttr('disabled');
					$('#resetSaveForm').click();
	            }
	        });
		}
	});

	$('#deleteWebsite').click(function(event) {
		jQuery.validator.addMethod("domain", function(value, element) {
			if (/^(?!\-)(?:[a-zA-Z\d\-]{0,62}[a-zA-Z\d]\.){1,126}(?!\d+)[a-zA-Z\d]{1,63}$/.test(value)) {
		        return true;   // PASS validation when REGEX matches
		    } else {
		        return false;  // FAIL validation
		    };
		}, 'Domain is incorrect');

		$('#deleteForm').validate({
			rules: {
	            deleteDomain: {
	            	domain:true,
	            }
	        },
	        messages:{
	            deleteDomain:{
	            	required: "This field is required."
	            },
	        },
		});

		var validResult = $('#deleteForm').valid();
		if(validResult){
			var url = "/cPanel/process.php";
	        var method = 'POST';
	        var delDomain = ($('#deleteDomain').val() && $('#deleteDomain').val() !== '') ? $('#deleteDomain').val() : '';

	        $.ajax({
	            url: url,
	            type: method,
	            data: {
	                postType: 0,
	                delDomain: delDomain,
	            },
	            beforeSend: function(){
	                $('#deleteWebsite').button('loading');
	                $("select, input").attr('disabled','disabled');
	            },
	            success: function(result) {
	            	if(result.length == 6){
	            		$('#delete_alert').hide().html(' <div class="alert alert-success alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+result+'</div>').fadeIn('400');
	            	}else{
	            		$('#delete_alert').hide().html(' <div class="alert alert-danger alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+result+'</div>').fadeIn('400');
	            	}
	            	
	            	$('#resetDeleteForm').click();
	            	$('#deleteWebsite').button('reset');
	            	$("select, input").removeAttr('disabled');
	            },
	            error: function(xhr, textStatus, error) {
	            	$('#delete_alert').hide().html(' <div class="alert alert-danger alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Can not delete the website. There is an error occured.</div>').fadeIn('400');
	            	$('#deleteWebsite').button('reset');
	            	$("select, input").removeAttr('disabled');
	            }
	        });
	    }
	});

	$('#filemanager').click(function(event) {
		var url = "/cPanel/filemanager.php";
	    var method = 'POST';

		$.ajax({
            url: url,
            type: method,
            data: {
                signal: 1,
            },
            beforeSend: function(){
                $('#filemanager').button('loading');
            },
            success: function(result) {
            	var data = JSON.parse(result);
				if(data.status == 1){
					window.open(data.url);
			// 		console.log(data.url);
			        // window.location.href = data.url;
			        // $('#openlink').attr('href',data.url);
			        // $('#openlink').click();
			        // $('#openlink').attr('href','');
				}else{
					alert(data.msg);
				}
            	$('#filemanager').button('reset');
			},
			async: false,
            error: function(xhr, textStatus, error) {
            	$('#filemanager').button('reset');
            }
        });
	});
	
	$('#installSSl').click(function(event) {
		jQuery.validator.addMethod("domain", function(value, element) {
			if (/^(?!\-)(?:[a-zA-Z\d\-]{0,62}[a-zA-Z\d]\.){1,126}(?!\d+)[a-zA-Z\d]{1,63}$/.test(value)) {
		        return true;   // PASS validation when REGEX matches
		    } else {
		        return false;  // FAIL validation
		    };
		}, 'Domain is incorrect');

		$('#sslForm').validate({
			rules: {
	            sslDomain: {
	            	domain:true,
	            },
	        },
	        messages:{
	            sslDomain:{
	            	required: "This field is required."
	            },
	            sslEmail: {
	                required: "This field is required.",
	                email: "Email is incorrect."
	            }
	        },
		});

		var validResult = $('#sslForm').valid();
		if(validResult){
			var url = "/cPanel/process.php";
	        var method = 'POST';
	        var sslDomain = ($('#sslDomain').val() && $('#sslDomain').val() !== '') ? $('#sslDomain').val() : '';
	        var sslEmail  = ($('#sslEmail').val()  && $('#sslEmail').val()  !== '') ? $('#sslEmail').val()  : '';
            
	        $.ajax({
	            url: url,
	            type: method,
	            data: {
	                postType: 2,
	                sslDomain: sslDomain,
	                sslEmail: sslEmail,
	            },
	            beforeSend: function(){
	                $('#installSSl').button('loading');
	                $("select, input").attr('disabled','disabled');
	            },
	            success: function(result) {
	                
	            	if(result.length == 328){
	            		$('#ssl_alert').hide().html(' <div class="alert alert-success alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>SSL certificate is already installed on your domain! Check <a target="_blank" href=https://'+sslDomain+'>HERE</a> out!</div>').fadeIn('400');
	            	}else{
	            		$('#ssl_alert').hide().html(' <div class="alert alert-danger alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'+result+'</div>').fadeIn('400');
	            	}
	            	
	            	$('#resetSslForm').click();
	            	$('#installSSl').button('reset');
	            	$("select, input").removeAttr('disabled');
	            },
	            error: function(xhr, textStatus, error) {
	            	$('#ssl_alert').hide().html(' <div class="alert alert-danger alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Can not install SSL on your domain. There is an error occured.</div>').fadeIn('400');
	            	$('#installSSl').button('reset');
	            	$("select, input").removeAttr('disabled');
	            }
	        });
	    }
	});
	
	$('#restartService').click(function(event) {
		var url = "/cPanel/process.php";
        var method = 'POST';
        
        $.ajax({
            url: url,
            type: method,
            data: {
                postType: 3,
            },
            beforeSend: function(){
                $('#restartService').button('loading');
                $("select, input").attr('disabled','disabled');
            },
            success: function(result) {
                alert('Executed..!');
            	$('#restartService').button('reset');
            },
            error: function(xhr, textStatus, error) {
            	alert('Executed..!');
            	$('#restartService').button('reset');
            	$("select, input").removeAttr('disabled');
            }
        });
	});
});