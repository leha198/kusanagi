<?php

$mysqli = new mysqli("localhost", "cpanel_user", "100faf1c", "c_panel");

if (!$mysqli) {
    die(json_encode(['status'=>0,'msg'=>'Connection to database is lost.']));
}

$setPassword = "100faf1c";

$hashedPassword = password_hash($setPassword, PASSWORD_DEFAULT);

if(!$mysqli->query("UPDATE accounts SET password='$hashedPassword' WHERE id = 1")){
	die(json_encode(['status'=>0,'msg'=>'An error occured when retrieving data.']));
}

$mysqli->close();
